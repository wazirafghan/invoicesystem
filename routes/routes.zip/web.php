<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/clear',function(){
    Artisan::call('config:clear');
    Artisan::call('cache:clear');
    Artisan::call('config:cache');
});

Route::get('/', function () {
    //return view('welcome');
    return redirect()->route('login');
});
Auth::routes();

Route::get('/', 'Theme\HomeController@index')->name('home');
Route::get('affiliate', 'Theme\HomeController@showAffiliate')->name('affiliate');
//Route::get('get-pound', 'Theme\HomeController@GetPoundEuro')->name('get-pound');
Route::get('user/dashboard', 'UserController@index')->name('user-dashboard');

Route::get('invoice', 'Theme\HomeController@invoice')->name('invoice');
Route::get('invoice', 'Theme\HomeController@invoice')->name('invoice');
Route::post('order-store', 'Theme\HomeController@orderStore')->name('order-store');
Route::get('cancel-orders', 'UserController@getCancelOrder')->name('get-cancel-orders');
Route::post('search-orders', 'UserController@getSearchOrder')->name('get-search-orders');
Route::get('user/edit/', 'UserController@edit')->name('user-edit');
Route::post('user/update/', 'UserController@update')->name('user-update');
Route::get('cancel-order/{id}', 'UserController@cancelOrder')->name('cancel-order');
Route::get('show-order/{id}', 'UserController@showOrder')->name('show-order');
Route::get('export-pdf/{id}', 'UserController@exportPdf')->name('export-pdf');
Route::get('make-payment/{id}', 'UserOrdersController@makePayment')->name('make-payment');
Route::get('make-payment-paypal/{id}', 'UserOrdersController@makePaymentPayPal')->name('make-payment-paypal');
Route::post('checkout', 'UserOrdersController@CheckOut')->name('processCheckout');
Route::post('checkout-paypal', 'UserOrdersController@ProcessPayPalCheckout')->name('processCheckoutPaypal');
Route::post('add-affiliate', 'Theme\HomeController@addAffiliate')->name('add-affiliate');
// route for check status of the payment
Route::get('status/{id}', 'UserOrdersController@getPaymentStatus');


Route::post('service-item/detail', 'Theme\HomeController@getServiceItemDetail')->name('getServiceItem');
Route::get('service-item/{slug}','Theme\HomeController@itemOrder')->where('slug','[\w\d\-\_]+');
Route::get('services/place-order/{slug}','Theme\HomeController@itemOrder')->where('slug','[\w\d\-\_]+');

Route::post('process-contact', 'Theme\HomeController@processContact')->name('process-contact');
Route::post('add-order', 'UserOrdersController@store')->name('add-order');
Route::get('session-order', 'UserOrdersController@sessionStore')->name('session-order');

//Comments
Route::post('comments/{post_id}', 'CommentsController@store');
Route::get('comments/{id}/delete', 'CommentsController@destroy');
Route::post('comment-status-modification', 'CommentsController@commentStatusChange');
Route::prefix('affiliate')->group(function() {
    Route::get('/login', 'Auth\AffiliateLoginController@showLoginForm')->name('affiliate.login');
    Route::post('/login', 'Auth\AffiliateLoginController@login')->name('affiliate.login.submit');
    Route::get('/dashboard', 'AffiliateController@index')->name('affiliate.dashboard');
    Route::get('/profile/{id}', 'AffiliateController@edit')->name('affiliate-profile');
    Route::patch('/update/{id}', 'AffiliateController@update')->name('affiliate-update');
    Route::get('/logout', 'Auth\AffiliateLoginController@logout')->name('affiliate.logout');

    // Password reset routes
    Route::post('/password/email', 'Auth\AffiliateForgotPasswordController@sendResetLinkEmail')->name('affiliate.password.email');
    Route::get('/password/reset', 'Auth\AffiliateForgotPasswordController@showLinkRequestForm')->name('affiliate.password.request');
    Route::post('/password/reset', 'Auth\AffiliateResetPasswordController@reset');
    Route::get('/password/reset/{token}', 'Auth\AffiliateResetPasswordController@showResetForm')->name('affiliate.password.reset');



});
Route::group([
    'middleware'    => ['auth:affiliate'],
    'prefix'        => 'affiliate',
    'namespace'     => 'Affiliate'
], function ()
{
    //Affiliate Routes
    Route::resource('affiliates','AffiliatesController');
    Route::get('get-links', 'AffiliatesController@getLinks')->name('get-links');
    Route::get('affiliate-info/{year}', 'AffiliatesController@getInfo')->name('affiliate-info');
    Route::get('withdraw-money', 'AffiliatesController@withdrawMoney')->name('withdraw-money');
    Route::post('withdraw', 'AffiliatesController@withdraw')->name('withdraw');
});


Route::prefix('admin')->group(function() {
    Route::get('/login', 'Auth\AdminLoginController@showLoginForm')->name('admin.login');
    Route::post('/login', 'Auth\AdminLoginController@login')->name('admin.login.submit');
    Route::get('/dashboard', 'AdminController@index')->name('admin.dashboard');
    Route::get('/profile/{id}', 'AdminController@edit')->name('admin-profile');
    Route::patch('/update/{id}', 'AdminController@update')->name('admin-update');
    Route::get('/logout', 'Auth\AdminLoginController@logout')->name('admin.logout');

    // Password reset routes
    Route::post('/password/email', 'Auth\AdminForgotPasswordController@sendResetLinkEmail')->name('admin.password.email');
    Route::get('/password/reset', 'Auth\AdminForgotPasswordController@showLinkRequestForm')->name('admin.password.request');
    Route::post('/password/reset', 'Auth\AdminResetPasswordController@reset');
    Route::get('/password/reset/{token}', 'Auth\AdminResetPasswordController@showResetForm')->name('admin.password.reset');



});
Route::group([
    'middleware'    => ['auth:admin'],
    'prefix'        => 'admin',
    'namespace'     => 'Admin'
], function ()
{

    //User Routes
    Route::resource('users','UsersController');
    Route::get('users/edit/{id}', 'UsersController@edit')->name('company-edit');
    Route::post('get-users', 'UsersController@getUsers')->name('admin.getUsers');
    Route::get('users/delete/{id}', 'UsersController@destroy')->name('user-delete');
    Route::post('delete-selected-users', 'UsersController@DeleteSelectedUsers')->name('delete-selected-users');
    Route::get('edit-profile/{id}', 'UsersController@show')->name('edit-profile');

    //Staff Routes
    Route::resource('staff','StaffController');
    Route::get('staff/edit/{id}', 'StaffController@edit')->name('company-edit');
    Route::post('get-staff', 'StaffController@getStaff')->name('admin.getStaff');
    Route::get('staff/delete/{id}', 'StaffController@destroy')->name('staff-delete');
    Route::post('delete-selected-staff', 'StaffController@DeleteSelectedStaff')->name('delete-selected-staff');
    Route::get('edit-profile/{id}', 'StaffController@show')->name('edit-profile');

    //Service Routes
    Route::resource('services','ServicesController');
    Route::get('services/edit/{id}', 'ServicesController@edit')->name('admin-services-edit');
    Route::post('get-services', 'ServicesController@getServices')->name('admin-getAddedServices');
    Route::get('services/delete/{id}', 'ServicesController@destroy')->name('admin-services-delete');
    Route::post('delete-selected-services', 'ServicesController@DeleteSelectedServices')->name('delete-selected-services');
    Route::post('services/detail', 'ServicesController@getServiceDetail')->name('admin-getServices');

    //Service-item Routes
    Route::resource('service-items','ServiceItemsController');
    Route::get('service-items/edit/{id}', 'ServiceItemsController@edit')->name('admin-service-items-edit');
    Route::post('get-service-items', 'ServiceItemsController@getServiceItems')->name('admin-getAddedServiceItems');
    Route::get('service-items/delete/{id}', 'ServiceItemsController@destroy')->name('admin-service-items-delete');
    Route::post('delete-selected-service-items', 'ServiceItemsController@DeleteSelectedServiceItems')->name('delete-selected-service-items');
    Route::post('service-items/detail', 'ServiceItemsController@getServiceItemDetail')->name('admin-getServiceItems');
    Route::post('service-items/image/save', 'ServiceItemsController@saveServiceImages')->name('admin.saveServiceImages');
    Route::get('service-items/remove/{id}', 'ServiceItemsController@deleteImage')->name('remove-image');
    Route::get('item-price/remove/{id}', 'ServiceItemsController@deletePrice')->name('remove-price');
    Route::get('service-items/{serviceId}/image/{imageId}', 'ServiceItemsController@deleteServiceImage')->name('admin.delete-service-image');

    //Forms Routes
    Route::resource('forms','FormsController');
    Route::get('forms/edit/{id}', 'FormsController@edit')->name('admin-forms-edit');
    Route::get('forms/edit-tooltip/{id}', 'FormsController@tooltipEdit')->name('admin-tooltip-edit');
    Route::post('get-forms', 'FormsController@getForms')->name('admin-getAddedForms');
    Route::post('tooltip-update', 'FormsController@tooltipUpdate')->name('tooltip-update');
    Route::get('forms/delete/{id}', 'FormsController@destroy')->name('admin-forms-delete');
    Route::post('delete-selected-forms', 'FormsController@DeleteSelectedForms')->name('delete-selected-forms');
    Route::post('forms/detail', 'FormsController@getFormDetail')->name('admin-getForms');

    //Affiliate Routes
    Route::resource('affiliates','AffiliatesController');
    Route::get('affiliates/edit/{id}', 'AffiliatesController@edit')->name('admin-affiliates-edit');
    Route::post('get-affiliates', 'AffiliatesController@getAffiliates')->name('admin-getAddedAffiliates');
    Route::get('affiliates/delete/{id}', 'AffiliatesController@destroy')->name('admin-affiliates-delete');
    Route::post('delete-selected-affiliates', 'AffiliatesController@DeleteSelectedAffiliates')->name('delete-selected-affiliates');
    Route::post('affiliates/detail', 'AffiliatesController@getAffiliateDetail')->name('admin-getAffiliates');

    //Affiliate Routes
    Route::resource('discounts','DiscountsController');
    Route::get('discounts/edit/{id}', 'DiscountsController@edit')->name('admin-discounts-edit');
    Route::post('get-discounts', 'DiscountsController@getDiscounts')->name('admin-getAddedDiscounts');
    Route::get('discounts/delete/{id}', 'DiscountsController@destroy')->name('admin-discounts-delete');
    Route::post('delete-selected-discounts', 'DiscountsController@DeleteSelectedDiscounts')->name('delete-selected-Discounts');
    Route::post('discounts/detail', 'DiscountsController@getAffiliateDetail')->name('admin-getDiscounts');

    //Orders Routes
    Route::resource('orders','OrdersController');
    Route::get('orders/edit/{id}', 'OrdersController@edit')->name('admin-orders-edit');
    Route::get('orders/show/{id}', 'OrdersController@show')->name('admin-orders-show');
    Route::get('orders/complete/{id}', 'OrdersController@complete')->name('admin-orders-complete');
    Route::post('get-orders', 'OrdersController@getOrders')->name('admin-getAddedOrders');
    Route::get('orders/delete/{id}', 'OrdersController@destroy')->name('admin-orders-delete');
    Route::post('delete-selected-orders', 'OrdersController@DeleteSelectedOrders')->name('delete-selected-orders');
    Route::post('orders/detail', 'OrdersController@getOrderDetail')->name('admin-getOrders');

    //Request Routes
    Route::resource('requests','RequestsController');
    Route::get('requests/edit/{id}', 'RequestsController@edit')->name('admin-requests-edit');
    Route::get('requests/show/{id}', 'RequestsController@show')->name('admin-requests-show');
    Route::get('requests/complete/{id}', 'RequestsController@complete')->name('admin-requests-complete');
    Route::post('get-requests', 'RequestsController@getRequests')->name('admin-getAddedRequests');
    Route::get('requests/delete/{id}', 'RequestsController@destroy')->name('admin-requests-delete');
    Route::post('delete-selected-requests', 'RequestsController@DeleteSelectedRequests')->name('delete-selected-requests');
    Route::post('requests/detail', 'RequestsController@getRequestDetail')->name('admin-getRequests');

    //Service Routes
    Route::resource('coupons','CouponsController');
    Route::get('coupons/edit/{id}', 'CouponsController@edit')->name('admin-coupons-edit');
    Route::post('get-coupons', 'CouponsController@getCoupons')->name('admin-getAddedCoupons');
    Route::get('coupons/delete/{id}', 'CouponsController@destroy')->name('admin-coupons-delete');
    Route::post('delete-selected-coupons', 'CouponsController@DeleteSelectedCoupons')->name('delete-selected-coupons');
    Route::post('coupons/detail', 'CouponsController@getCouponDetail')->name('admin-getCoupons');

    //Setting Routes
    Route::resource('privileges','PrevilegesController');

    //Setting Routes
    Route::resource('settings','SettingsController');
});
